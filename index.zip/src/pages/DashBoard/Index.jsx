import { AppSidebar } from "@/components/app-sidebar";

const Dashboard = () => {
  return (
    <div>
      <AppSidebar />
    </div>
  );
};

export default Dashboard;
