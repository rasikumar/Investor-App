import LoginPage from "./pages/AuthPage/LoginPage";

const App = () => {
  return (
    <div>
      {/* <LoginPage /> */}
      <h1>asdasd</h1>
      <Dashboard />
    </div>
  );
};

export default App;
